﻿using System.Collections;
using System.Collections.Generic;
using System.Web.Http;
using Autofac;
using CompanyName.$safeprojectname$.Components.Data;
using CompanyName.$safeprojectname$.Components.DI;
using CompanyName.$safeprojectname$.Components.Entities;
using DotNetNuke.Web.Api;

namespace CompanyName.$safeprojectname$.Components.WebApi
{
    public class ModuleNameController : DnnApiController
    {

        public IDataRepository DataRepository { get; set; }
        
        public ModuleNameController()
        {
            Bindings.Container.InjectUnsetProperties(this);
        }

        [HttpGet]
        [AllowAnonymous]
        public TestEntity GetTestEntity()
        {
            var testEntity = new TestEntity() {Id = 0, ModuleId = ActiveModule.ModuleID, Name = "Hello World"};
            return testEntity;
        }


        //Primary Attributes

        //[HttpPost]
        //[HttpGet]
        //[AllowAnonymous]
        //[RequireHost]
        //[ValidateAntiForgeryToken]
        //[DnnModuleAuthorize(AccessLevel = SecurityAccessLevel.View)]
        //[DnnModuleAuthorize(AccessLevel = SecurityAccessLevel.Edit)]
        



    }
}