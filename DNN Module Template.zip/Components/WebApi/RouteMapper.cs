﻿using System.Web.Http;
using DotNetNuke.Web.Api;

namespace CompanyName.$safeprojectname$.Components.WebApi
{
    public class RouteMapper : IServiceRouteMapper
    {
        public void RegisterRoutes(IMapRoute mapRouteManager)
        {
            mapRouteManager.MapHttpRoute("CompanyName/$safeprojectname$", "Default", "{controller}/{action}/{id}", new
            {
                id = RouteParameter.Optional,
                action = "Get"
            }, new string[] { "CompanyName.$safeprojectname$.Components.WebApi" });
        }
    }
}