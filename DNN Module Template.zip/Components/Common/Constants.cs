﻿namespace CompanyName.$safeprojectname$.Components.Common
{
    public class Constants
    {
        public const string RelativeClientPath = @"DesktopModules\CompanyName\$safeprojectname$\Client\";
        public const string RelativeImagePath = @"\DesktopModules\CompanyName\$safeprojectname$\Images\";
        public const string ApiPath = @"CompanyName/$safeprojectname$";
        public const string FullApiPath = @"DesktopModules/CompanyName/$safeprojectname$";
    }
}