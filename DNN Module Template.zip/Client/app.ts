﻿ /// <reference path="references.ts" />
module CompanyName {
    export module $safeprojectname$ {
        export var serviceRoot: string = $safeprojectname$.serviceRoot || "";
        export var templatePath: string;
        export var servicesFramework: any;

        
        //Initalizes angular app
        $("html").attr("ng-app", "$safeprojectname$");
        export var app: ng.IModule = angular.module('$safeprojectname$', ['rx']);

    }
}